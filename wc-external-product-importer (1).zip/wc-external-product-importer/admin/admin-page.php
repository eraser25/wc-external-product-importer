<?php
if (!defined('ABSPATH')) exit;
function wc_ext_admin_page(){ include __DIR__.'/page-view.php'; }
?>